#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv){
	char *input;
	char *output;
	char *filename_1 = "fifo_to.fifo";
	char *filename_2 = "fifo_in.fifo";
	int ssize=1;
	if(access(filename_1, F_OK)==-1)
	if (mknod(filename_1, S_IFIFO | 0666, 0) < 0)
	{
		exit(-1);
	}
	if(access(filename_2, F_OK)==-1)
	if (mknod(filename_2, S_IFIFO | 0666, 0) < 0)
	{
		exit(-1);
	}
	//printf("arg=%d\n", atoi(argv[1]));
	input=calloc(1000, sizeof(char));
	output=calloc(1000, sizeof(char));
	if (atoi(argv[1]) == 0)
	{
		//printf("asd\n");
		pid_t pid = fork();
		if (pid == 0){	
			
			int fd_1;
			fd_1= open(filename_1, O_WRONLY);
			//printf("%d\n", fd_1);
			fflush(stdout);
			fflush(stderr);
			while (1)
			{
				
				fgets(input,1000*sizeof(char),stdin);
				//printf("You wrote: %s\n", input);
				if(strlen(input)<1) sleep(0.1);
				else{
					printf("Writing to pipe...\n");
					//write(fd_1, strlen(input), 4);
					write(fd_1,input,(1000)*sizeof(char));
					printf("Written.\n");
					//fflush(fd_1);
				}
				
			}
		}else{
			int fd_2 = open(filename_2, O_RDONLY);
			while (1)
			{
			
				//read(fd_2, &ssize, sizeof(int));
				//printf("%d\n", ssize);
				int er=read(fd_2, output, 1000);
				printf("%d er \n",er);
				printf("re_1:%s", output);
			}
		}
	}
	if (atoi(argv[1]) == 1)
	{
		//printf("asd\n");
		pid_t pid = fork();
		if (pid == 0){	
			
			int fd_1;
			fd_1= open(filename_2, O_WRONLY);
			//printf("%d\n", fd_1);
			fflush(stdout);
			fflush(stderr);
			while (1)
			{
				
				fgets(input,1000*sizeof(char),stdin);
				//printf("You wrote: %s\n", input);
				if(strlen(input)<1) sleep(0.1);
				else{
					printf("Writing to pipe...\n");
					//write(fd_1, strlen(input), 4);
					write(fd_1,input,(1000)*sizeof(char));
					printf("Written.\n");
					//fflush(fd_1);
				}
				
			}
		}else{
			int fd_2 = open(filename_1, O_RDONLY);
			while (1)
			{
			
				//read(fd_2, &ssize, sizeof(int));
				//printf("%d\n", ssize);
				int er=read(fd_2, output, 1000);
				printf("%d er \n",er);
				printf("re_2:%s", output);
			}
		}
	}
	return 0;	
}
		
